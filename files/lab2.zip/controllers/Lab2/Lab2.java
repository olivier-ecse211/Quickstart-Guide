/**
 * Wrapper class for webots to start the main project function
 */
public class Lab2 {
  public static void main(String[] args) {
    ca.mcgill.ecse211.project.Main.main(args);
  }
}
