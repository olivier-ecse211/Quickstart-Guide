package ca.mcgill.ecse211.project;

import com.cyberbotics.webots.controller.Robot;
import com.cyberbotics.webots.controller.DistanceSensor;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Wrapper class around Webots' DistanceSensor class to simulate Lejos' EV3UltrasonicSensor class
 * The main difference is that the constructor uses the name of the sensor object on the robot rather than the port number
 Lejos API:
  http://www.lejos.org/ev3/docs/lejos/hardware/sensor/EV3UltrasonicSensor.html
 Webots API:
  https://cyberbotics.com/doc/reference/distancesensor?tab-language=java
 */

public class EV3UltrasonicSensor {

  /**
   * Reference to the robot that contains the sensor
   */
  Robot parentRobot;
  
  /**
   * The Webots sensor we will interface with
   */
  final DistanceSensor target;
 
  /**
   * Lock for the sensor
   */
  private static Lock lock = new ReentrantLock();
  
  public EV3UltrasonicSensor(Robot robot,String name) {
   parentRobot=robot;
   //Get target sensor
   target = robot.getDistanceSensor(name);
   enable();
  }
  /**
   * Enable the sensor.
   */
  public void enable() {
    lock.lock();
    try {
      //Set the timestep to that of the robot
      target.enable((int)parentRobot.getBasicTimeStep());
    } catch (Exception e) {
      System.err.println("Ultrasonic enable exception: " + e.getMessage());
    } finally {
      lock.unlock();
    }
  }
  
  /**
   * Disable the sensor.
   */
  public void disable() {
    lock.lock();
    try {
      target.disable();
    } catch (Exception e) {
      System.err.println("Ultrasonic disable exception: " + e.getMessage());
    } finally {
      lock.unlock();
    }
  }
    

  public int sampleSize() {
   return 1;
  }

  public EV3UltrasonicSensor getDistanceMode(){
   return this;
  }
    
  /**
   * Disable the sensor.
   */
  public void fetchSample(float[] sample, int offset) {
    lock.lock();
    try {
      sample[0]=(float)(target.getValue()/100.0);
    } catch (Exception e) {
      System.err.println("Ultrasonic fetchSample exception: " + e.getMessage());
    } finally {
      lock.unlock();
    }
    //TODO: check battery level to add more noises
  }
  
  

}
