package ca.mcgill.ecse211.project;

import static ca.mcgill.ecse211.project.Resources.*;
import ca.mcgill.ecse211.project.Odometer;
import ca.mcgill.ecse211.project.SquareDriver;

import java.lang.Thread;
import java.util.concurrent.CyclicBarrier;

import com.cyberbotics.webots.controller.Robot;

/**
 * Main class of the program.
 */
public class Main {
  
  /**
   * Main entry point - instantiate objects used and set up sensor.
   * 
   * @param args not used
   */
  public static void main(String[] args) {
    //Run a few physics step to make sure everything is initialized and has settled properly
    for(int i=0;i<50;i++){
      robot.step((int)robot.getBasicTimeStep());
    }
      
    new Thread(odometer).start();
    SquareDriver.drive();

    // Main simulation loop
    while (true) {
     // perform the physics step
     try {
        barrier.await();
        if(robot.step((int)robot.getBasicTimeStep()) == -1)break;
        barrier.await();
      } catch (Exception e) {
        System.err.println("Exception: " + e.getMessage());
      }
    }
    System.exit(0);
  }

  /**
   * Sleeps for the specified duration.
   * @param millis the duration in milliseconds
   */
  public static void sleepFor(long millis) {
    for(double i=0;i<(double)millis/robot.getBasicTimeStep();i++){
      try {
        barrier.await();
        //physics step is performed here by the loop in the main thread
        barrier.await();
      } catch (Exception e) {
        System.err.println("Exception: " + e.getMessage());
      }
    }  
  }

  public static void waitUntilNextStep() {
    try {
      barrier.await();
      //physics step is performed here by the loop in the main thread
      barrier.await();
    } catch (Exception e) {
      System.err.println("Exception: " + e.getMessage());
    }
  }
  
}
