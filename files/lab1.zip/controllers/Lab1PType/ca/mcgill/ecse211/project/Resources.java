package ca.mcgill.ecse211.project;

import com.cyberbotics.webots.controller.Robot;

import ca.mcgill.ecse211.project.EV3LargeRegulatedMotor;
import ca.mcgill.ecse211.project.EV3UltrasonicSensor;
import ca.mcgill.ecse211.project.EV3ColorSensor;
import ca.mcgill.ecse211.project.EV3Speaker;

import java.util.concurrent.CyclicBarrier;

/**
 * Class for static resources (things that stay the same throughout the entire program execution),
 * like constants and hardware.
 * <br><br>
 * Use these resources in other files by adding this line at the top (see examples):<br><br>
 * 
 * {@code import static ca.mcgill.ecse211.project.Resources.*;}
 */
public class Resources {
  //Parameters: adjust these for desired performance
  
  /**
   * Ideal distance between the sensor and the wall (cm).
   */
  public static final int WALL_DIST = 20;
  
  /**
   * Width of the maximum tolerated deviation from the ideal {@code WALL_DIST}, also known as the
   * dead band. This is measured in cm.
   */
  public static final int WALL_DIST_ERR_THRESH = 3;
  
  /**
   * Speed of slower rotating wheel (deg/sec).
   */
  public static final int MOTOR_LOW = 25;
  
  /**
   * Speed of the faster rotating wheel (deg/sec).
   */
  public static final int MOTOR_HIGH = 200;
  
  /**
   * The limit of invalid samples that we read from the US sensor before assuming no obstacle.
   */
  public static final int INVALID_SAMPLE_LIMIT = 20;
  
  /**
   * The poll sleep time, in milliseconds.
   */
  public static final int POLL_SLEEP_TIME = 50;
  
  /**
   * CyclicBarrier to control execution, one party per thread (main/UltrasonicController)
   */
  public static CyclicBarrier barrier = new CyclicBarrier(2);
  
  // Hardware resources

  /**
   * The webots robot
   */
  public static final Robot robot = new Robot();

  /**
   * The ultrasonic sensor.
   */
  public static final EV3UltrasonicSensor usSensor = new EV3UltrasonicSensor(robot,"sensorDistance");

  /**
   * The left motor.
   */
  public static final EV3LargeRegulatedMotor leftMotor = new EV3LargeRegulatedMotor(robot,"motorLeft");

  /**
   * The right motor.
   */
  public static final EV3LargeRegulatedMotor rightMotor = new EV3LargeRegulatedMotor(robot,"motorRight");
  
  // Software resources

  /**
   * The ultrasonic controller
   */
  public static UltrasonicController ultrasonicController = new UltrasonicController();

  /**
   * CyclicBarrier to control execution, one party per thread (main/UltrasonicController)
   */
  public static CyclicBarrier barrier = new CyclicBarrier(2);

  /**
   * The embedded speaker
   */
  public static EV3Speaker Sound = new EV3Speaker(robot);
  
}
