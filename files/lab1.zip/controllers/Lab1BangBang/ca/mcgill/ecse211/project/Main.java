package ca.mcgill.ecse211.project;

import static ca.mcgill.ecse211.project.Resources.*;
import ca.mcgill.ecse211.project.UltrasonicController;

import java.lang.Thread;

import com.cyberbotics.webots.controller.Robot;
import com.cyberbotics.webots.controller.Motor;

/**
 * Main class of the program.
 */
public class Main {

  /**
   * Main entry point - instantiate objects used and set up sensor.
   * @param args not used
   */
  public static void main(String[] args) {

    //Run a few physics step to make sure everything is initialized and has settled properly
    for(int i=0;i<50;i++){
      robot.step((int)robot.getBasicTimeStep());
    }
  
    // Start the controller thread
    new Thread(ultrasonicController).start();

    // Main simulation loop
    while (true) {
      try {
        //Wait for all threads to be synchronized
        barrier.await();
        // perform the physics step
        if(robot.step((int)robot.getBasicTimeStep()) == -1)break;
        //Wait for all threads to be synchronized
        barrier.await();
      } catch (Exception e) {
        // Nothing to do here but print information about the exception
        System.err.println("Exception: " + e.getMessage());
      }
    }
  }

  /**
   * Sleeps for the specified duration.
   * @param millis the duration in milliseconds
   */
  public static void sleepFor(long millis) {
    for(double i=0;i<(double)millis/robot.getBasicTimeStep();i++){
      waitUntilNextStep();
    }
  }
  
  /**
   * Sleep until the next physics step is performed
   */
  public static void waitUntilNextStep() {
    try {
      //Wait until all threads reach this point
      barrier.await();
      //physics step is performed here by the main thread
      //wait until the update is done
      barrier.await();
    } catch (Exception e) {
      // Nothing to do here but print information about the exception
      System.err.println("Exception: " + e.getMessage());
    }
  }
  

  /**
   * Sleeps for the specified duration (version for the real robot)
   * @param millis the duration in milliseconds
   */
  /*
  public static void sleepFor(long millis) {
    try {
      Thread.sleep(millis);
    } catch (InterruptedException e) {
      // Nothing to do here
    }
  }
  */

  
}
