package ca.mcgill.ecse211.project;

import com.cyberbotics.webots.controller.Robot;
import com.cyberbotics.webots.controller.Camera;
import com.cyberbotics.webots.controller.LED;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Wrapper class around Webots' Camera class to simulate Lejos' EV3ColorSensor class
 * We simulate the color sensor by using a single pixel camera (a 1x1 image)
 * The main difference is that the constructor uses the name of the sensor object on the robot rather than the port number
 Lejos API:
  http://www.lejos.org/ev3/docs/lejos/hardware/sensor/EV3ColorSensor.html
 Webots API:
  https://cyberbotics.com/doc/reference/camera?tab-language=java
 * @author Olivier St-Martin Cormier
 */


public class EV3ColorSensor {

  /**
   * Reference to the robot that contains the sensor
   */
  private Robot parentRobot;
  
  /**
   * The Webots sensor we will interface with
   */
  private final Camera target;
  
  /**
   * The light on the Webots sensor we will interface with
   */
  private final LED light;
  
  /**
   * Sampling mode
   */
  private int mode;
  
  /**
   * Lock for the sensor
   */
  private static Lock lock = new ReentrantLock();

  public EV3ColorSensor(Robot robot,String name) {
   parentRobot=robot;
   //Get target sensor
   target = parentRobot.getCamera(name);
   light = parentRobot.getLED(name+"-light");
   mode=0;//Default to mode 0 (red)
   enable();
  }

  private EV3ColorSensor(EV3ColorSensor source,int mode) {
   parentRobot=source.parentRobot;
   //Get target sensor
   target = source.target;
   light = source.light;
   mode=mode;
  }
  
  /**
   * Enable the sensor.
   */
  public void enable() {
    lock.lock();
    try {
      //Set the timestep to that of the robot
      target.enable((int)parentRobot.getBasicTimeStep());
    } catch (Exception e) {
      System.err.println("ColorSensor enable exception: " + e.getMessage());
    } finally {
      lock.unlock();
    }
    setFloodlight(true);
  }
  
  /**
   * Disable the sensor.
   */
  public void disable() {
    lock.lock();
    try {
      target.disable();
    } catch (Exception e) {
      System.err.println("ColorSensor disable exception: " + e.getMessage());
    } finally {
      lock.unlock();
    }
    setFloodlight(false);
  }

  
  public EV3ColorSensor getRedMode(){
   setFloodlight(true);
   return new EV3ColorSensor(this,0);
  }
  
  public EV3ColorSensor getRGBMode(){
   setFloodlight(true);
   return new EV3ColorSensor(this,1);
  }
  
  public EV3ColorSensor getAmbientMode(){
   setFloodlight(false);
   return new EV3ColorSensor(this,2);
  }
  
  
  //TODO: Add some noise?
  public void fetchSample(float[] sample,int offset){
    lock.lock();
    try {
      //Red mode
      if(mode==0)sample[0]=Camera.imageGetRed(target.getImage(),target.getWidth(),0,0);
      //RGB mode
      else if(mode==1){
       sample[0]=Camera.imageGetRed(target.getImage(),target.getWidth(),0,0);
       sample[1]=Camera.imageGetGreen(target.getImage(),target.getWidth(),0,0);
       sample[2]=Camera.imageGetBlue(target.getImage(),target.getWidth(),0,0);
      }
      //Ambiant mode, returns the average of the three channels
      else if(mode==2){
       float r=Camera.imageGetRed(target.getImage(),target.getWidth(),0,0);
       float g=Camera.imageGetGreen(target.getImage(),target.getWidth(),0,0);
       float b=Camera.imageGetBlue(target.getImage(),target.getWidth(),0,0);
       sample[0]=(r+g+b)/3;
      }    
    } catch (Exception e) {
      System.err.println("ColorSensor fetchSample exception: " + e.getMessage());
    } finally {
      lock.unlock();
    }
  }
  
  
  /*
   * Turns the default LED light on or off.
   */
  public void setFloodlight(boolean floodlight){
    lock.lock();
    try {
      light.set(floodlight?1:0);
    } catch (Exception e) {
      System.err.println("ColorSensor setFloodlight exception: " + e.getMessage());
    } finally {
      lock.unlock();
    }
  }
  
  /*
   * Checks if the floodlight is currently on.
   */
  public boolean isFloodlightOn(){
    int state=0;
    lock.lock();
    try {
      state=light.get();
    } catch (Exception e) {
      System.err.println("ColorSensor isFloodlightOn exception: " + e.getMessage());
    } finally {
      lock.unlock();
    }
    return state==1?true:false;
  }
  
}
